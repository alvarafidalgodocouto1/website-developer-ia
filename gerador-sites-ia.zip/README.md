# Gerador de Websites com IA

Projeto base para gerar websites automaticamente com IA, com preview antes do pagamento.

## Estrutura
- backend/: API FastAPI
- frontend/: formulário simples

## Executar localmente
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
